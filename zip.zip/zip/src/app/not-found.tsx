export default function NotFound(){ return <main><h1>404</h1><p>Página no encontrada.</p></main>; }
