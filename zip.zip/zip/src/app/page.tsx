'use client';
import { Box, Container, Typography, Button } from '@mui/material';
import Banner from '@/components/Banner';
import FeatureSection from '@/components/FeatureSection';
import ProjectGrid from '@/components/ProjectGrid';
import ContactForm from '@/components/ContactForm';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <Box>
      <Banner />
      
      <FeatureSection 
        title="Tecnología co-creada con comunidades"
        description="En Voces, desarrollamos herramientas digitales junto a comunidades indígenas de América Latina, el Caribe y las islas del Pacífico. Nos enfocamos en el desarrollo tecnológico como vía para fortalecer la lengua, la identidad y la autonomía cultural de los pueblos originarios."
        imageSrc="/images/pic01.png"
        imageAlt="Co-creación tecnológica"
      />

      <FeatureSection 
        title="Lenguas que viven en la tecnología"
        description="Creamos herramientas de traducción automática, transcripción, herramientas educativas y más, adaptadas a las realidades lingüísticas y culturales de los pueblos originarios. Estas tecnologías no solo preservan lenguas, sino que las proyectan hacia el futuro digital."
        imageSrc="/images/pic02.png"
        imageAlt="Lenguas indígenas"
        reverse
      />

      <FeatureSection 
        title="Respeto, identidad y futuro"
        description="Nos sentimos orgullosos de contribuir al fortalecimiento de la identidad cultural mediante tecnologías diseñadas desde una perspectiva intercultural. En Voces, creamos herramientas para potenciar las posibilidades de cada lengua y comunidad."
        imageSrc="/images/pic03.png"
        imageAlt="Tecnología intercultural"
      />

      <ProjectGrid />
      <ContactForm />
      <Footer />
    </Box>
  );
}
