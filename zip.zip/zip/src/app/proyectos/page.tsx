import { Typography } from '@mui/material';
export default function Page(){ return <Typography variant="h3">Proyectos</Typography>; }
