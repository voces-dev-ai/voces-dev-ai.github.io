'use client';
import { Box, Container, Grid, Typography, Link, Stack, IconButton } from '@mui/material';
import GitHubIcon from '@mui/icons-material/GitHub';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';

export default function Footer() {
  return (
    <Box 
      component="footer" 
      sx={{ 
        bgcolor: 'primary.main',
        color: 'white',
        py: 6,
        mt: 'auto'
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom>
              Voces CNIA
            </Typography>
            <Typography variant="body2">
              Tecnología en tu propia lengua.
              Preservando y fortaleciendo las lenguas originarias a través de la tecnología.
            </Typography>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom>
              Enlaces
            </Typography>
            <Stack spacing={1}>
              <Link href="/proyectos" color="inherit">Proyectos</Link>
              <Link href="/contacto" color="inherit">Contacto</Link>
              <Link href="https://github.com/voces-dev-ai" target="_blank" color="inherit">
                GitHub
              </Link>
            </Stack>
          </Grid>
          
          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom>
              Síguenos
            </Typography>
            <Stack direction="row" spacing={1}>
              <IconButton href="https://github.com/voces-dev-ai" color="inherit">
                <GitHubIcon />
              </IconButton>
              <IconButton href="#" color="inherit">
                <LinkedInIcon />
              </IconButton>
              <IconButton href="#" color="inherit">
                <TwitterIcon />
              </IconButton>
            </Stack>
          </Grid>
        </Grid>
        
        <Typography 
          variant="body2" 
          align="center" 
          sx={{ mt: 4, opacity: 0.7 }}
        >
          © {new Date().getFullYear()} Voces CNIA. Todos los derechos reservados.
        </Typography>
      </Container>
    </Box>
  );
}